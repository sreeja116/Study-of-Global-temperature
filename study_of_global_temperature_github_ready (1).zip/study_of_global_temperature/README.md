# Study of Global Temperature | Machine Learning

## Overview
A beginner-friendly machine learning project that analyzes a time series of annual global-temperature anomalies and demonstrates trend prediction with Python.

> **Important:** The included CSV is a synthetic demonstration dataset created for reproducibility and learning. It is **not** NASA observational data and should not be presented as official climate measurements.

For a real-data version, NASA GISTEMP v4 provides global-mean monthly and annual temperature-anomaly data from 1880 to the present.

## Objectives
- Load and inspect temperature time-series data
- Clean and prepare the dataset
- Visualize long-term temperature trends
- Create time-based features
- Train a Linear Regression model
- Evaluate predictions using MAE and R²
- Forecast a small future period

## Technologies
Python, Pandas, NumPy, Matplotlib, Scikit-learn, Jupyter Notebook

## Project Structure
```text
data/
  global_temperature_demo.csv
notebooks/
  global_temperature_analysis.ipynb
images/
requirements.txt
README.md
```

## Run
```bash
pip install -r requirements.txt
jupyter notebook
```

Then open `notebooks/global_temperature_analysis.ipynb`.

## Data Source Note
The project structure is designed so the demo CSV can later be replaced with NASA GISTEMP data.
NASA GISTEMP v4 documentation: https://data.giss.nasa.gov/gistemp/
